To change drive icons, Place the icon and a copy of the autorun.inf files in the drive.
Then open the autorun.inf file (with notepad) and chnage the ICON=drive-icon.ico to the icon's name you are using. then save it.
after that, HIDE both icon and autorun.inf files so they won't be visible.

Reboot might be needed for icons to be updated. DONE!

- @sameera_s_w